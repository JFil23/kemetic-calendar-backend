# Reproducibility receipt

## Complete input tuple used

- Mobile SHA:
  `d3ebcc216c2626b9df463f7e2ab2c8b6dcd57e5a`
- Mobile tree:
  `bf24e71a38ae4eb07daf33b2c4cd1ac90c399660`
- Builder SHA-256:
  `10d8a39619b26faab1961a04da233d211ba3ef3a19f5ae10cf0bd048d83d0fdc`
- `pubspec.lock` SHA-256:
  `e366b4717d33df04c32c011d29877b133c2fb7941319f6b4ddf2b0650af8153c`
- Staging configuration SHA-256:
  `216fe26e1f5bf676549b532db176e8a4866bd6a94d385a2dc374dfabdcc24dda`
- Fixed build identity:
  `repro-d3ebcc2-config-216fe26e`
- Flutter:
  `3.35.3`
- Framework:
  `a402d9a4376add5bc2d6b1e33e53edaae58c07f8`
- Engine:
  `ddf47dd3ff96dbde6d9c614db0d7f019d7c7a2b7`
- Dart:
  `3.9.2`
- Python:
  `3.13.1`
- Bash:
  `3.2.57`
- Node:
  `22.12.0`
- `WEB_SOURCE_MAPS=0`
- `TZ=UTC`
- `LC_ALL=C`
- `COPYFILE_DISABLE=1`
- `SOURCE_DATE_EPOCH=1785093491`
- known environment-configuration overrides unset.

Two fresh source extractions were used:

- `/private/tmp/kemet-repro-a.Ev3chk`
- `/private/tmp/kemet-repro-b.i6rjzC`

## Payload result

- Build A manifest file:
  `repro-a.payload.sha256`
- Build A manifest SHA-256:
  `e5120651b6f3401ac68f2bc0ee96b553508f1affc1bdab81fe67ec6bc869f780`
- Build B manifest file:
  `repro-b.payload.sha256`
- Build B manifest SHA-256:
  `ecffd9b98e659f13a6b13341795049e181b80bd6c10e72bc9f59a2dcf1fc6af9`
- File counts: 79 and 79.
- Identical bodies: 77.
- Different bodies: `.last_build_id`, `version.json`.

Verdict: `FAIL — COMPLETE SUBSTANTIVE OUTPUT IS NOT REPRODUCIBLE`.

## Packaging result

Two ordinary gzip tar archives of the same unchanged build tree differed:

- `bce873…`
- `f4688…`

Their uncompressed tar payload hashes were identical:

`6004f9…`

Two normalized `tar | gzip -n` archives of the same tree were identical:

`538b7dc32e88c05b27ef46492185955bcd555112898de130e61af3279d96ed81`

Verdict:

- Payload builder: not reproducible.
- Archive packaging for an already fixed tree: reproducible with normalization.
