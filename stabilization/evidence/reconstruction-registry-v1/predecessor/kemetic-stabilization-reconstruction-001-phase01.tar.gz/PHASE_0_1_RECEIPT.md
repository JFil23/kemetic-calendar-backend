# STABILIZATION-RECONSTRUCTION-001 — Phase 0–1 receipt

Date: 2026-07-26 America/Los_Angeles

Scope: read-only reconstruction and build-pipeline characterization. No product
source, configuration, deployment, GitHub, Supabase, Simulator, or production
state was changed.

## Executive verdict

- The proposed A–G source history is a strict direct-parent chain in both the
  parent and mobile repositories.
- Every parent checkpoint points to the exact corresponding mobile checkpoint.
- Checkpoint F is test-only and is not a distinct runtime candidate.
- Checkpoint D is the first broad mixed-authority runtime layer.
- The two artifacts built from mobile `d3ebcc216c2626b9df463f7e2ab2c8b6dcd57e5a`
  are materially different and must remain separate evidence objects.
- Their seven differing files are all attributed. `manifest.json` and part of
  `index.html` came from an undocumented RC identity mutation that is not
  reproducible from the clean source and recorded builder.
- A clean, controlled, identical-input two-build experiment produced identical
  bytes for 77 of 79 files. `.last_build_id` and `version.json` remained
  nondeterministic.
- Ordinary gzip tar packaging was nondeterministic. A normalized
  `tar | gzip -n` recipe produced identical package bytes for the same tree.
- Therefore source ancestry is closed, but build-input closure and complete
  output reproducibility are not closed.

## Source checkpoints

| ID | Parent | Mobile | Classification |
|---|---|---|---|
| A | `23a0ae7833da93450c5c74f98915c5ea0f6ba6d4` | `198d9d43bd4858328f05b0a785f1f38df7010214` | `MERGED_BASELINE` |
| B | `9499b95379ed1cd582c5b3c5cff574868a9e4058` | `74aae821f4d2adb359527fc26af0f34a3f22e05d` | `AUTH_ORIGIN_ATTEMPT` |
| C | `93499ae04b717b966f87716c8d0d5a1afd75719a` | `f61ea029987c683b599292b00c8c48f4ec23a1c1` | `USER_OBSERVED_CONTROL` |
| D | `b043c208ffa981da97cd7c9316cdb496fe74e85c` | `0c8b90eb08b657d5f90dbc6f1f2050aabb91c094` | `BROAD_LATENCY_CALENDAR_JOURNAL_FLOW_LAYER` |
| E | `5dc7ea80d8ea829c9bfc45103c90c036646946b4` | `59d5c8ee988ca35bda56d46d06ef9ec1f76e5579` | `NAV_CLOSE_LAYER` |
| F | `447713cc741475a8be323f627eb49a8d5df8d7e5` | `ed2003046a99af5f28e36c9b6d76516485259a38` | `TEST_ONLY` |
| G | `460a1f65cf3f6f5036dbafe863ee82217b00359d` | `d3ebcc216c2626b9df463f7e2ab2c8b6dcd57e5a` | `REJECTED_COMBINED_STACK` |

All B–G transitions are direct-parent transitions. No synthetic cherry-pick
history is needed for reconstruction unless a future isolated checkpoint must
be decomposed semantically.

## Checkpoint deltas

- B mobile: 9 files, `+738/-36`, web authentication origin/callback/platform
  work.
- C mobile: 8 files, `+340/-25`, web authentication session persistence.
- D mobile: 9 files, `+510/-42`, Flow Studio, Calendar shared-state loading,
  Journal controller/overlay and route behavior. This is the clear mixed
  authority checkpoint.
- E mobile: 3 files, `+143/-20`, centralized close-navigation fallback.
- F mobile: 1 test file, `+2/-0`; no runtime delta.
- G mobile: 8 files, `+56/-10`, close-navigation behavior across six feature
  pages plus tests.

## Artifact and evidence separation

Source, artifact, deployment, and physical-evidence verdicts are separate.
Evidence from one artifact is never transferred to another artifact sharing the
same source SHA.

### Checkpoint C

- Archive SHA-256:
  `587d6cd311e52db72c36240c030f3e986f12f60621b3ec085a1bf303162a93d1`
- Manifest SHA-256:
  `68b1912c60ebe5be76023695b5fe0b10e380e49695a20ca8f5902358214970c2`
- Immutable deployment:
  `https://3783add2.kemet-autostab-20260714.pages.dev`
- Classification:
  `USER_OBSERVED_CONTROL — AUTH/BORDERS PASS — COMPLETE PHYSICAL TODAY/X MATRIX NOT PROVEN`

This is useful control evidence, not a release acceptance. Its embedded
`APP_SITE_URL` names an older preview, demonstrating that its build-input
authority was not closed even though the initiating-origin authentication
behavior was user-observed to work.

### Checkpoint G, artifact G1

- Archive SHA-256:
  `a9b9e8518dd2462dd28cc882a32d870bf2c8ccf4e8764761485a78b8b25dd894`
- Manifest SHA-256:
  `4b922e5ed10fb4dd57dc8a5b24327a0a85ed2e6ec5929577a27e9949bed2cf7d`
- Immutable deployment:
  `https://e68efd77.kemet-autostab-20260714.pages.dev`
- Recording SHA-256:
  `07b2128efa29a026c76d4e8998f73f1bd3294d47f41dc9e5bef3b77ed69420ac`
- Classification:
  `PHYSICAL_RED — X PASS / STANDALONE FAIL`

### Checkpoint G, artifact G2

- Archive SHA-256:
  `3016958c53212cc0aade369d44c29e14b3a9b9c37681d101ea251833d5ab5cbd`
- Manifest SHA-256:
  `943e1e0dbd3c034fe2e6e1ece14c72844f9d8fad597cd673e355acd27815272c`
- Immutable deployment:
  `https://10f63b78.kemet-autostab-20260714.pages.dev`
- Classification:
  `USER_REPORTED_PHYSICAL_RED — BORDERS/TODAY — NO HASHED RECORDING`

G2 passed local/Simulator container checks, but the later physical report stated
that Safari chrome remained and Today failed on the first tap. The report lacks
a new identity-bound recording, so it is not silently upgraded to stronger
evidence.

Checkpoint G itself remains `REJECTED_COMBINED_STACK`. Neither G artifact is a
repair or release candidate.

## The seven G1/G2 file differences

| Path | Cause |
|---|---|
| `.last_build_id` | Flutter-generated build/configuration identity |
| `env.json` | `APP_SITE_URL` changed |
| `flutter_bootstrap.js` | injected build-version string changed |
| `index.html` | build version plus undocumented RC title/Apple identity |
| `main.dart.js` | compiled `APP_SITE_URL`; substituting only that URL makes the files identical |
| `manifest.json` | undocumented RC name, short name and manifest ID |
| `version.json` | build identity plus current UTC timestamp |

The manifest difference is:

- G1/tracked: name `Kemetic Calendar`, short name `ḥꜣw`, ID `/`.
- G2: name `Kemet Close RC`, short name `Kemet X RC`, ID
  `/kemet-close-rc`.

The tracked source and build script do not perform that transformation.
Therefore G2 necessarily includes an unrecorded pre-build source edit or
post-build mutation. This is a build-input-closure failure and a live lead for
the installed-PWA identity confusion.

## Complete-input experiment

Two fresh source extractions of exact mobile G were built with:

- source SHA:
  `d3ebcc216c2626b9df463f7e2ab2c8b6dcd57e5a`
- source tree:
  `bf24e71a38ae4eb07daf33b2c4cd1ac90c399660`
- staging environment artifact SHA-256:
  `216fe26e1f5bf676549b532db176e8a4866bd6a94d385a2dc374dfabdcc24dda`
- fixed build version:
  `repro-d3ebcc2-config-216fe26e`
- `WEB_SOURCE_MAPS=0`
- `TZ=UTC`
- `LC_ALL=C`
- `COPYFILE_DISABLE=1`
- `SOURCE_DATE_EPOCH=1785093491`
- Flutter 3.35.3, framework
  `a402d9a4376add5bc2d6b1e33e53edaae58c07f8`, engine
  `ddf47dd3ff96dbde6d9c614db0d7f019d7c7a2b7`, Dart 3.9.2.

Both builds produced 79 files. Exactly 77 matched. The two mismatches were:

- `.last_build_id`: a fresh Flutter-generated value.
- `version.json`: a fresh current-UTC timestamp.

No runtime payload reference to `.last_build_id` was found, but it remains in
the substantive set until runtime irrelevance is affirmatively established.
`version.json` is an intentionally served runtime identity file and cannot be
excluded.

Verdict: **output reproducibility failed**.

## Packaging experiment

Packaging the same build tree twice with a normal gzip tar command yielded
different archive hashes because the gzip timestamp was ambient.

Packaging the same tree twice with `COPYFILE_DISABLE=1`, stable ordering and
`gzip -n` yielded the same archive SHA-256 both times:

`538b7dc32e88c05b27ef46492185955bcd555112898de130e61af3279d96ed81`

No unsafe or AppleDouble paths were present in that deterministic package.
Packaging is mechanically closable; the builder output is not yet closed.

## Build-input closure verdict

The current builder consumes or depends on:

- tracked source and asset files;
- a hardcoded default configuration;
- ignored `web/env.json`;
- automatically selected ignored `env/prod.json` or `env/dev.json`;
- an externally supplied environment file;
- twelve process-level configuration overrides;
- `ENV_FILE`, `WEB_BUILD_VERSION`, `WEB_SOURCE_MAPS`, `TMPDIR`, clock,
  locale/timezone, `PATH`, SDK installation and pub cache;
- dependency resolution because the build does not use `--no-pub`;
- dirty source state when the direct builder is used;
- an unpinned deployment client when the deploy wrapper is used.

The builder does not bind `APP_SITE_URL` to the declared deployment/install
origin. The deploy wrapper rebuilds instead of uploading a previously verified
artifact.

Verdict:

`BUILD INPUT CLOSURE FAILED — HISTORICAL ARTIFACTS ARE VERIFIABLE BUT NOT REPRODUCIBLE FROM CLEAN GIT + RECORDED INPUTS`

## Minimum correction required before reconstruction or release

1. Replace automatic/ambient environment selection with one explicit named
   public environment artifact and SHA-256; reject process-key overrides.
2. Require `APP_SITE_URL` to equal the declared unique deployment/install
   origin.
3. Make manifest/RC identity a declared versioned input, never a temporary
   source or artifact mutation.
4. Pin and verify Flutter framework, engine, Dart, dependency lock, builder
   script and packaging tool identities.
5. Resolve dependencies with an enforced lockfile and build with `--no-pub`.
6. Require explicit deterministic build ID, source-date epoch and source-map
   mode.
7. Generate a pre-build input receipt and post-build 79-file manifest.
8. Make `.last_build_id` deterministic or prove it is safely omitted; make
   `version.json` deterministic.
9. Normalize file order, ownership, modes, timestamps, gzip headers and macOS
   metadata.
10. Separate build from upload. Exact-artifact upload must never rebuild.
11. Pin the deployment client and never overwrite a candidate alias with new
    bytes.

No implementation of these corrections was authorized or performed.

## Pause

Reconstruction, checkpoint builds, deployments and product corrections remain
paused. The next action is a separately reviewed build-pipeline correction,
followed by renewed artifact generation. Product regression reconstruction
must not begin until `SHA + named environment + pinned builder/toolchain`
actually determines one substantive artifact.

Final status:

`BUILD INPUT CLOSURE CHARACTERIZED — LINEAR REGRESSION CHAIN VERIFIED — AWAITING BUILD-PIPELINE CORRECTION AUTHORIZATION`
