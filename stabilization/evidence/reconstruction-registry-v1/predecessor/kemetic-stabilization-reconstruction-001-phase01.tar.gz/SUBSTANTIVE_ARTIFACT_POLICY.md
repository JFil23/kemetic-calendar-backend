# Substantive artifact policy

The substantive set is defined before interpreting reproducibility results.

## Included

All 79 deployed file bodies are substantive by default, including:

- `manifest.json`;
- `env.json`;
- `index.html`;
- `main.dart.js`;
- `flutter_bootstrap.js`;
- `version.json`;
- `.last_build_id`;
- all assets, fonts, CanvasKit/Skwasm files, icons and control files present in
  the local artifact.

`version.json` is runtime-visible build identity and cannot be excluded.
`.last_build_id` remains included unless its runtime irrelevance and safe
omission are affirmatively established.

## Exclusions

No deployed file body is excluded in this phase.

Archive-container metadata may be normalized without changing the substantive
payload:

- gzip timestamps and original filename fields;
- tar owner/group names and IDs;
- tar entry timestamps after binding them to `SOURCE_DATE_EPOCH`;
- macOS extended attributes, AppleDouble files and provenance headers;
- deterministic entry ordering.

These are packaging metadata, not permission to omit `manifest.json`,
`env.json`, `version.json`, `.last_build_id`, or any other deployed file.
