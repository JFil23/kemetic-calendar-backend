# Build-input inventory

## Repository inputs

- Exact parent commit/tree:
  `460a1f65cf3f6f5036dbafe863ee82217b00359d` /
  `1f8ca6ba3b4550e3b89ef4b94181a3fb0759b6d4`
- Exact mobile commit/tree:
  `d3ebcc216c2626b9df463f7e2ab2c8b6dcd57e5a` /
  `bf24e71a38ae4eb07daf33b2c4cd1ac90c399660`
- Builder SHA-256:
  `10d8a39619b26faab1961a04da233d211ba3ef3a19f5ae10cf0bd048d83d0fdc`
- Deploy wrapper SHA-256:
  `21d7361998be55c2fd86c01b9d8a7568e6a7051486546a73baa8ba04db8a2787`
- `pubspec.yaml` SHA-256:
  `c3a417e83654f57d83b06d941546f333d6e1e89015f7dee9338125335b9427b3`
- `pubspec.lock` SHA-256:
  `e366b4717d33df04c32c011d29877b133c2fb7941319f6b4ddf2b0650af8153c`
- `.metadata` SHA-256:
  `2be0592f4f679dcb485692ae985fcbf038d0363d0f87accb927db7de7ac891de`
- tracked `web/manifest.json` SHA-256:
  `b0c98ab77fc90922d97ea598c912b7145d6ba16797e89ae2539c2d02a147f12b`

The builder and dependency lock are unchanged across A–G.

## Dependency inputs

- 116 locked packages.
- 109 hosted packages.
- 7 Flutter/Dart SDK packages.
- No Git or path dependencies.
- Compilation depfile: 2,142 Dart inputs, including 1,091 pub-cache files
  and 665 Flutter-SDK files.
- Asset depfile: 147 inputs, including 110 pub-cache files and 4 SDK files.

Versions are locked, but the exact SDK and package-cache content digests are not
captured by the historical release receipt.

## Configuration precedence

The current builder merges:

1. hardcoded defaults;
2. ignored `web/env.json`;
3. a selected external/ignored environment file;
4. twelve process environment variables.

When no environment file is named, it automatically selects ignored
`env/prod.json` before `env/dev.json`.

Other ambient inputs include `ENV_FILE`, `WEB_BUILD_VERSION`,
`WEB_SOURCE_MAPS`, `TMPDIR`, current clock, `PATH`, SDK installation, pub
cache/network resolution, Python/Bash/Git/tool versions, locale/timezone and
dirty source state.

The historical command did not bind the path and digest of its staging
environment file or record a sanitized process-variable inventory.

## Toolchain observed

- Flutter 3.35.3
- Flutter framework `a402d9a4376add5bc2d6b1e33e53edaae58c07f8`
- Flutter engine `ddf47dd3ff96dbde6d9c614db0d7f019d7c7a2b7`
- Dart 3.9.2
- Python 3.13.1
- Bash 3.2.57
- macOS 15.7.4
- Node 22.12.0
- npm/npx 10.9.0

The builder does not enforce this complete tuple.

## Closure defects

- `APP_SITE_URL` is plausibility-checked but not required to equal the declared
  deployment/install origin.
- The build runs without `--no-pub`.
- `WEB_SOURCE_MAPS` affects output but is not included in `version.json`.
- `WEB_BUILD_VERSION` defaults to Git short SHA plus the current clock.
- `version.json` always records the current UTC time.
- Direct builder invocation does not reject a dirty worktree.
- The deploy wrapper rebuilds and can allow dirty deployment.
- The deployment client is `wrangler@latest`, not an exact version.
- The stable G2 manifest and HTML identity were mutated by an unrecorded input.

Input-closure verdict: `FAIL`.
